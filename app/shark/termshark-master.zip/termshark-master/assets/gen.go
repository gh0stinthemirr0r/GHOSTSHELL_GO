//go:generate statik -src=. -f

package assets
