// Copyright 2019-2022 Graham Clark. All rights reserved.  Use of this source
// code is governed by the MIT license that can be found in the LICENSE
// file.

package termshark

var Version string = "v2.4.0+"

//======================================================================
// Local Variables:
// indent-tabs-mode: nil
// tab-width: 4
// fill-column: 78
// End:
